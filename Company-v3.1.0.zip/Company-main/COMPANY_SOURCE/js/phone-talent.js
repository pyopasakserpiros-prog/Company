(function(root,factory){'use strict';const api=factory(typeof module==='object'&&module.exports?require('./human-core'):root.CompanyCore);if(typeof module==='object'&&module.exports)module.exports=api;else root.CompanyPhoneTalent=api;})(typeof globalThis!=='undefined'?globalThis:this,function(H){
'use strict';
const SUBJECTS={
  chip:'semiconductor_physics',
  fabless_soc:'semiconductor_physics',
  wafer_foundry:'semiconductor_process',
  osat_packaging:'smt_process',
  dram_memory:'circuit_design',
  nand_storage:'embedded_firmware',
  camera_module:'semiconductor_optics',
  display_panel:'electrical_basics',
  display:'electrical_basics',
  battery_pack:'power_electronics',
  battery:'power_electronics',
  pcb_rf:'smt_process',
  materials:'smt_process',
  enclosure:'metal_machining',
  os_platform:'software',
  hardware:'electrical_basics',
  software:'software',
  manufacturing:'semiconductor_process'
};
const PREREQ={
  semiconductor_physics:'physical_chemistry',
  physical_chemistry:'chemical_processing',
  semiconductor_process:'chemical_processing',
  semiconductor_optics:'electrical_basics',
  power_electronics:'electrical_basics',
  circuit_design:'electrical_basics',
  smt_process:'electrical_basics',
  electronics:'electrical_basics',
  software:'programming',
  embedded_iot:'programming',
  embedded_firmware:'programming'
};
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function hash(s){let n=2166136261;for(const c of String(s))n=Math.imul(n^c.charCodeAt(0),16777619);return n>>>0;}
function day(w){if(Number.isFinite(w.clock?.absoluteMinute))return Math.floor(w.clock.absoluteMinute/1440)+1;return Number.isFinite(w.day)?w.day:Number.isFinite(w.clock?.day)?w.clock.day:Math.floor((w.minute||w.time?.minute||0)/1440)+1;}
function state(w){return w.phoneTalent||(w.phoneTalent={version:1,people:{},firms:{},offers:[],payrollDays:{},history:[]});}
function discipline(role){
  if(/(?:^|_)(?:software|os|platform)(?:_|$)/.test(role))return 'software';
  if(/foundry|fab|manufactur|assembl|osat/.test(role)&&role!=='fabless_soc')return 'manufacturing';
  if(/chip|semi|soc/.test(role))return 'chip';
  return 'hardware';
}
function seedSubjects(subject,level){const out={};let s=subject;while(s){out[s]=level;s=PREREQ[s];}return out;}
function roleExtras(role,pid){
  const base={software:40+hash(pid)%25,programming:45,semiconductor_process:40,chemical_processing:40,circuit_design:45,metrology:40,metal_machining:45,embedded_firmware:40};
  if(role==='camera_module')return {...base,semiconductor_optics:48+hash(pid+'opt')%18,quality:42};
  if(role==='dram_memory')return {...base,semiconductor_physics:46+hash(pid+'dram')%18,circuit_design:48+hash(pid+'ckt')%16,quality:40};
  if(role==='nand_storage')return {...base,embedded_firmware:48+hash(pid+'nand')%18,semiconductor_process:44,quality:40};
  if(role==='battery_pack'||role==='battery')return {...base,power_electronics:46+hash(pid+'pwr')%18,electrical_safety:48,quality:40};
  if(role==='pcb_rf'||role==='materials'||role==='osat_packaging')return {...base,smt_process:46+hash(pid+'smt')%18,electrical_basics:46,quality:40};
  if(role==='fabless_soc')return {...base,semiconductor_physics:48+hash(pid+'soc')%18,circuit_design:48,embedded_firmware:44};
  if(role==='os_platform')return {...base,software:50+hash(pid+'os')%18,programming:48,embedded_firmware:45};
  return base;
}
function ensure(w,firms){const t=state(w);for(const [key,f]of Object.entries(firms||{})){const id=f.id||key;if(t.firms[id])continue;const role=f.role||key,disc=discipline(role),count=2+hash(w.seed+id)%3;const record=t.firms[id]={id,role,personIds:[]};for(let i=0;i<count+2;i++){const pid='phone-person-'+id+'-'+i,profile=H.createProfile(w.seed,pid),job=i===0?'ceo':i===count+1?'commercial':'engineer',subject=job==='ceo'?'people_management':job==='commercial'?'procurement':(SUBJECTS[role]||SUBJECTS[disc]);const p={id:pid,name:['อรุณ','มาลี','นที','กานต์','ศิริ','ธารา'][hash(pid)%6]+' '+['วัฒนกิจ','ชาญวิชา','อินทรา','พงษ์ศิลป์','กิจวัฒนา','เรืองปัญญา'][hash(pid+'surname')%6],profile,state:H.createState(profile),role:job,discipline:disc,employerId:id,employment:'external',dailyWageSatang:job==='ceo'?180000:job==='engineer'?100000:65000,satisfaction:65+hash(pid+'sat')%21,loyalty:40+hash(pid+'loyal')%41,education:{practiceMinutes:{},interests:[],course:null,subjects:{...seedSubjects(subject,45+hash(pid+'knowledge')%26),...(job==='engineer'?roleExtras(role,pid):{})},appliedMinutes:{},history:[]},history:[{day:day(w),type:'employed',firmId:id}],duties:job==='ceo'?'ประเมินทุน ความเสี่ยง และแผนธุรกิจ':job==='engineer'?'วิจัย ทดสอบ และตรวจคุณภาพ':'จัดซื้อและดูแลลูกค้า',workDay:-1,workedMinutes:0};t.people[pid]=p;record.personIds.push(pid);}}return t;}
function staff(w,id){const t=state(w);return (t.firms[id]?.personIds||[]).map(pid=>t.people[pid]).filter(p=>p&&p.employment==='external'&&p.employerId===id&&!w.people?.some(q=>q.id===p.id&&q.employed));}
function level(p,s){return p.education?.subjects?.[SUBJECTS[s]||s]||0;}
function capability(w,id,s){const people=staff(w,id).filter(p=>p.role==='engineer');return people.length?Math.max(...people.map(p=>level(p,s))):0;}
// Payroll is a claim once per firm/day; the caller posts the returned wages to actual firm/nation accounts.
function payroll(w,id){const t=state(w),d=day(w);if(t.payrollDays[id]===d)return 0;t.payrollDays[id]=d;return staff(w,id).reduce((n,p)=>n+p.dailyWageSatang,0);}
function work(w,id,subject,maxMinutes=360){const s=SUBJECTS[subject]||subject,d=day(w),contributors=[];let effectiveMinutes=0,personMinutes=0;for(const p of staff(w,id).filter(p=>p.role==='engineer').sort((a,b)=>level(b,s)-level(a,s))){if(p.workDay!==d){p.workDay=d;p.workedMinutes=0;}const minutes=Math.max(0,Math.min(360-p.workedMinutes,Number.isFinite(maxMinutes)?maxMinutes:0));if(!minutes||!level(p,s))continue;const before=level(p,s),prereq=PREREQ[s];if(prereq&&level(p,prereq)<20)continue;const condition=clamp(((p.state.energy??75)+(100-(p.state.stress??20)))/160,.2,1);const effective=minutes*(before/100)*condition/(1+contributors.length*.2);p.workedMinutes+=minutes;personMinutes+=minutes;effectiveMinutes+=effective;p.education.appliedMinutes[s]=(p.education.appliedMinutes[s]||0)+minutes;const aptitude=p.profile.aptitudes.learningSpeed??50,potential=Object.values(p.profile.potential).reduce((a,b)=>a+b,0)/30;p.education.subjects[s]=Math.min(75+potential*.25,before+minutes/60*.025*(.5+aptitude/100)*condition);contributors.push({personId:p.id,minutes,effectiveMinutes:effective,subject:s});}const wageSatang=payroll(w,id);return {day:d,minutes:effectiveMinutes,effectiveMinutes,personMinutes,wageSatang,contributors};}
function negotiateRecruitment(w,personId,offer,hooks={}){const t=state(w),p=t.people[personId];if(!p||p.employment!=='external')return {ok:false,reason:'ไม่พบผู้สมัครที่ยังทำงานภายนอก'};const salary=offer?.dailyWageSatang||0,vacancy=offer?.vacancy===true;const premium=salary/p.dailyWageSatang,threshold=1.1+p.loyalty/250+(p.role==='ceo'?.5:0)+(p.satisfaction-60)/300;const assessment=hooks.assess?hooks.assess(p,offer):{ok:true};const accepted=vacancy&&salary>0&&premium>=threshold&&assessment?.ok!==false;const row={id:'phone-offer-'+(t.offers.length+1),personId,day:day(w),salarySatang:salary,accepted,noticeUntilDay:day(w)+3+Math.floor(p.loyalty/25),status:accepted?'notice':'declined',reason:accepted?'รายได้และตำแหน่งใหม่คุ้มค่าต่อการย้ายงาน':'ตำแหน่ง รายได้ หรือความมั่นคงยังไม่เพียงพอ'};t.offers.push(row);return {ok:accepted,...row};}
function recruitToCampus(w,id,createCallback){const t=state(w),p=t.people[id],offer=[...t.offers].reverse().find(o=>o.personId===id&&o.status==='notice');if(!p||p.employment!=='external'||!offer||day(w)<offer.noticeUntilDay||typeof createCallback!=='function')return {ok:false,reason:'ยังไม่ครบเงื่อนไขย้ายงาน'};const campus=createCallback(p,offer);if(!campus||campus.id!==p.id)return {ok:false,reason:'สร้างบุคคลด้วยตัวตนเดิมไม่สำเร็จ'};campus.profile=p.profile;campus.education=p.education;campus.state=p.state;campus.name=p.name;if(campus.identity){campus.identity.fullName=p.name;campus.identity.displayName=p.name;}p.employment='campus';const former=p.employerId;p.employerId=null;offer.status='transferred';p.history.push({day:day(w),type:'campus_transfer',formerFirmId:former});return {ok:true,person:campus,formerFirmId:former};}
function step(w,d,hooks={}){const t=state(w);for(const p of Object.values(t.people)){if(p.employment!=='external')continue;const offer=hooks.evaluateRecruitment?.(p);if(offer&&!t.offers.some(o=>o.personId===p.id&&o.status==='notice'))negotiateRecruitment(w,p.id,offer,hooks);}if(hooks.createPerson)for(const o of t.offers)if(o.status==='notice'&&d>=o.noticeUntilDay)recruitToCampus(w,o.personId,hooks.createPerson);return t;}
function view(w){return w.phoneTalent?JSON.parse(JSON.stringify(w.phoneTalent)):null;}
function validate(w){const errors=[],t=w.phoneTalent;if(!t)return errors;if(t.version!==1)errors.push('phoneTalent version');for(const [id,p]of Object.entries(t.people||{})){if(p.id!==id||p.profile?.id!==id)errors.push(id+': identity');for(const e of H.validateProfile(p.profile))errors.push(id+': '+e);if(!Number.isFinite(p.dailyWageSatang)||p.dailyWageSatang<0||!Number.isInteger(p.dailyWageSatang))errors.push(id+': wage');if(!Number.isFinite(p.workedMinutes)||p.workedMinutes<0||p.workedMinutes>360)errors.push(id+': work budget');for(const n of Object.values(p.education?.subjects||{}))if(!Number.isFinite(n)||n<0||n>100)errors.push(id+': subject');if(p.employment==='external'&&(!t.firms[p.employerId]?.personIds.includes(id)||w.people?.some(q=>q.id===id&&q.employed)))errors.push(id+': duplicate/missing employer');}for(const f of Object.values(t.firms||{}))for(const id of f.personIds||[])if(!t.people[id])errors.push(id+': missing person');return errors;}
return {SUBJECTS,ensure,capability,work,payroll,view,validate,negotiateRecruitment,recruitToCampus,step};
});
