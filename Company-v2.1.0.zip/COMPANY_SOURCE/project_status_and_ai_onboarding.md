# สถานะ Company Simulation — รุ่นเกม v2.1.0

อัปเดตสถานะจาก source ของ `main` ที่ฐาน commit `6182e0a662bf1dfe47360e64e20e635ea07abeae` พร้อมการพัฒนาแพตช์ **v2.1.0** (`business-world-metals-entry-audit-2026-11`) วันที่ 11 พฤศจิกายน 2026 เอกสารนี้สรุปสิ่งที่ตรวจพบใน repo และชุดทดสอบจริง; รายงานแพตช์เก็บผลตามเวลาที่รัน

## รุ่นและขอบเขต

- **รุ่นเกม:** `D.VERSION` และ `D.RELEASE_VERSION` = `2.1.0` ใน `COMPANY_SOURCE/js/data.js` และ `COMPANY_SOURCE/js/sim.js`
- **รุ่นข้อมูล catalog:** `1.2.0`; **รุ่น package.json:** `0.1.0`; **รุ่นสถานะโลกใน sim/save:** `0.1.0`; **Human Core:** `1.0.0` — ตัวเลขเหล่านี้เป็นคนละส่วน ไม่ใช่รุ่นเกม
- เกมเป็นบริษัทจำลองหลายธุรกิจที่ NPC และผู้บริหารขับเคลื่อนกิจการเอง ผู้เล่นเฝ้าดู ปรับเวลา/มุมมอง และใช้ Sandbox Edit Hub ทดลองแก้ข้อมูลบริษัท/ตัวละคร/ทรัพยากรเพื่อดูผลต่อโลก NPC
- แกน `COMPANY_SOURCE/js/human-core.js` ถูกล็อก SHA-256 `fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32` ครอบคลุมบุคลิก 14 ค่า ค่านิยม 18 ค่า ความถนัด 30 ค่า และสภาวะ 12 ค่า

## สิ่งที่มีในเกมปัจจุบัน (v2.1.0)

| ระบบ | สิ่งที่ยืนยันได้ใน source/การทดสอบ |
|---|---|
| นิคมและองค์กร | แผนที่นิคม 56×34, แปลงก่อสร้าง 14 จุด, โครงสร้างองค์กร 4 ชั้นและสายอาชีพ 10 ระดับ รวมระบบพื้นที่ อาคาร และการทำงานของคน |
| บุคลากรและการดำเนินงาน | NPC มีโปรไฟล์/ทักษะ/อาชีพและทำงานผ่าน simulation; งานเชื่อมคน เครื่องจักร สถานี ผลิต คลัง ขนส่ง และบัญชี โดยไม่เปลี่ยนสูตร Human Core |
| แค็ตตาล็อกอุตสาหกรรม | วัตถุดิบ **64** ชนิดใน 10 คลาส (`T0_NATURAL` 9, `T1` 37, `T2` 10, `T3` 8), สูตรแปรรูป **40** สูตร, สินค้า **40** ชนิดใน 10 ตระกูล, ห่วงโซ่การผลิต **13** สาย (`TRUE_RESOURCE_CHAIN_TABLE` 9 สาย) และโดเมนความสามารถ 9 ด้าน |
| ต้นน้ำและเกษตร/เหมือง | มีทรัพยากรธรรมชาติจริง 9 ชนิดแยกจากเมล็ด/พืชผล/วัตถุดิบแปรรูป; เหมือง `silica_copper_mine` ขุดได้ทั้ง `silica_bauxite_ore`, `copper_iron_ore`, `iron_ore` และ `bauxite_ore` ตามสำรองเหมืองจริง; สายถลุงโลหะมี `coke_reducing_flux`, `alumina_billet`, `structural_steel_plate`, `aluminum_extrusion_profile`, `nickel_cobalt_matte` และกากแร่ `mineral_slag_mud` พร้อมการบำบัดกากแร่ `treatMineralSlag` |
| โมเดลธุรกิจ | มี 8 process models: อาหาร/เบเกอรี่, อิเล็กทรอนิกส์และ RMA, ยานยนต์/เปลี่ยน tooling, เวชภัณฑ์ปลอดเชื้อ, ต้นน้ำเกษตร/ปศุสัตว์/เหมือง/ป่าไม้, ขนส่ง B2B, ซอฟต์แวร์/SaaS และบริการวิศวกรรม B2B |
| บริการ B2B | **8 แบบ:** `calibration_lab`, `field_maintenance`, `industrial_recycling`, `battery_second_life_lab`, `returnable_pallet_pool`, `cold_storage_3pl`, `energy_epc_install` (รับเหมาติดตั้งระบบพลังงานโซลาร์/กักเก็บไฟ B2B), `b2b_technical_academy` (ศูนย์ฝึกอบรมและรับรองทักษะวิศวกรรม B2B) พร้อมการจองงาน/ทรัพยากรและข้อจำกัดตามชนิดบริการ |
| ขนส่งและสายการค้า | รถ 3 ชนิด (`dry_6w`, `reefer_6w`, `heavy_10w`) ที่มี `leaseDepositSatang` (`dailyLeaseCost × 5`) ตรงกันทั้งใน `data.js`, evaluator และ `acquireFleetVehicle`; เส้นทางขนส่ง **6 เส้นทาง** (`FREIGHT_ROUTES`) และทางเดินการค้าภูมิภาค **4 สาย** (`D.TRADE_CORRIDORS`: นิกเกิล-แบตเตอรี่อินโดนีเซีย-ไทย, แร่เหล็ก-โครงสร้างโซลาร์ออสเตรเลีย-ไทย, โคลด์เชนอาเซียนผ่านสิงคโปร์ฮับ, เวชภัณฑ์ปลอดเชื้อและกริดอินเดีย) |
| ซอฟต์แวร์ | รับงานพัฒนาและ SaaS มีขั้นพัฒนา/ทดสอบ/ส่งมอบ การกันเงินมัดจำ และรายได้สมาชิกตามผู้ใช้ที่เกิดจริง; ต้องมีผู้พัฒนาที่มีความสามารถ |
| การตัดสินใจลงทุนของ NPC (แก้บั๊กครบใน v2.1.0) | `evaluateExecutiveBoardAndBusinessEntry` ทำงานในเวลางานจริง (`tod(w) === 645` / 10:45 น.) ขณะ CEO/ผู้นำอาวุโสทำงานอยู่ ไม่ติด `deferred_no_executive_authority` ตอนเที่ยงคืน; แยก `committedBudgetSatang` (งบที่จองผ่าน `reserveBoardBudget`) ออกจาก `paidCapitalTotalSatang` (เงินลงทุนที่จ่ายจริงแล้วและตัดผ่าน `consumeBoardReservation`) ไม่หักเงินซ้ำ; รองรับบริษัทขนาดเล็ก (<10 คน) เปิดธุรกิจขนาดย่อมได้; บังคับใช้ `nextReviewDay` และ `topicCooldowns`; และจัดอันดับเลือกบริการ/ลูกค้าตามความพร้อมจริง |
| โลกภายนอกยุค 2.1.0 | มี **12** ประเทศ/กลุ่มเศรษฐกิจ (`TH`, `US`, `CN`, `JP`, `EU`, `ME`, `RU_EE`, `ASEAN`, `ID`, `AU`, `IN`, `SG`), **16** เหตุการณ์โลก, และบริษัทภายนอก **22** แห่ง ผลส่งผ่านไปยัง FX, น้ำมัน, ค่าขนส่ง, lead time, ราคาวัตถุดิบ, ดีมานด์ และบันทึกในพงศาวดารโลก |
| Save/API/UI | Save ตรวจโครงสร้างสถานะเกมรวม `executiveBoard` (`reservations`, `paidCapitalTotalSatang`, `topicCooldowns`); API ส่ง snapshot/พงศาวดารและ `tradeCorridors` ให้ UI; รองรับ `continueEndless` เดินเกมต่อหลังบรรลุเป้าหมาย безหยุดกลางคัน |

### รายการเพิ่มและจุดที่แก้ใน v2.1.0

- **แก้บั๊ก NPC Business-Entry Audit ครบ 7 จุด:**
  1. ย้ายการประเมินอัตโนมัติของบอร์ดจาก `settleDay` ตอนเที่ยงคืน มาเป็นเวลางาน `tod(w) === 645` (10:45 น.) ใน `step(w)` ทำให้ CEO ที่มีตัวตนในออฟฟิศอนุมัติหรือชะลอโครงการได้จริงโดยไม่ต้องพึ่ง `ignoreAtWork: true`
  2. เพิ่ม `leaseDepositSatang` (`900,000` / `1,250,000` / `1,700,000` สตางค์) ใน `FLEET_VEHICLES` และให้ `acquireFleetVehicle` รองรับทั้งอ็อบเจกต์ `{ ownership: "leased" }` และสตริง `"leased"` พร้อมคืน `costSatang` ตรงกัน ไม่มี `NaN`
  3. แยกงบที่จองไว้ (`committedBudgetSatang` / `eb.reservations`) ออกจากทุนที่จ่ายออกไปแล้ว (`paidCapitalTotalSatang`) ด้วย `reserveBoardBudget`, `consumeBoardReservation` และ `cancelBoardReservation` ไม่หักซ้ำกับเงินสดที่ลดลงแล้ว
  4. เปิดทางให้บริษัทขนาดเล็ก (<10 คน) ประเมินและเริ่มธุรกิจที่เหมาะสมกับกำลังคนและเงินสดอิสระได้ (เช่น เช่ารถ 1 คัน หรือเปิดบริการ B2B ที่ใช้นักเทคนิค 1 คน) โดยไม่ติด deadlock
  5. เปลี่ยนเกณฑ์เงินสดของ `service_entry` ให้ตรวจ `remainingUncommitted` หลังหักเงินสำรองอยู่รอดแทน `w.finance.cash` ดิบ
  6. เปลี่ยนการเลือกชนิดบริการและลูกค้าจาก round-robin/รายแรก มาเป็นการให้คะแนนความต้องการตลาด อัตรากำไร ความพร้อมของอะไหล่ และความสัมพันธ์ลูกค้า
  7. บังคับใช้ `nextReviewDay` และ `eb.topicCooldowns` เพื่อไม่ให้บอร์ดบันทึกมติซ้ำเรื่องเดิมทุกวันก่อนถึงรอบทบทวน
- **สายโลหะขั้นบันได (Stepped Metals & Extrusion Ladder):**
  - วัตถุดิบใหม่ 6 ชนิด: `coke_reducing_flux`, `alumina_billet`, `structural_steel_plate`, `mineral_slag_mud`, `nickel_cobalt_matte`, `aluminum_extrusion_profile` (รวมเป็น 64 ชนิด)
  - สูตรแปรรูปใหม่ 5 สูตรใน `MATERIAL_RECIPES` (รวมเป็น 40 สูตร) พร้อม `alternativeInputs` บน `metal_sheet`, `heat_sink` และ `cathode_electrolyte` เพื่อให้ทั้งสายแร่เดิมและสายโลหะแยกชนิดทำงานร่วมกันได้ และมีระบบบำบัดกากแร่ `treatMineralSlag`
  - สินค้าใหม่ 4 ชนิด: `solar_mounting_rail_kit`, `ev_battery_tray_assembly`, `industrial_switchgear_cabinet`, `high_nickel_nmc_module` (รวมเป็น 40 ชนิด)
- **บริการ B2B ใหม่ 2 ประเภท (รวม 8 ประเภท):** `energy_epc_install` และ `b2b_technical_academy`
- **ประเทศใหม่ 4 ประเทศ เหตุการณ์โลก 4 เหตุการณ์ บริษัทต่างชาติ 4 แห่ง และทางเดินการค้า 4 สาย:**
  - ประเทศ: `ID` (อินโดนีเซีย), `AU` (ออสเตรเลีย), `IN` (อินเดีย), `SG` (สิงคโปร์)
  - เหตุการณ์: `indonesia_nickel_bauxite_ban`, `australia_pilbara_cyclone_iron_shock`, `singapore_asean_coldchain_corridor`, `india_apac_clean_grid_pharma_boom`
  - บริษัทคู่ค้า: `nusantara_nickel`, `pilbara_resources`, `bharat_biotech_it`, `singapore_port_3pl`

## ผลตรวจล่าสุดใน checkout นี้ (v2.1.0)

| คำสั่ง | ผล |
|---|---|
| `npm test` | ผ่าน **136/136 tests** (รวมชุดทดสอบใหม่ `test/business-depth-world-corridors-v210.test.cjs`) |
| `npm run check` | ผ่าน รวมการตรวจ Locked Human Core hash (`fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`) |
| `npm run build` | ผ่าน; สร้างไฟล์ HTML เดี่ยว `1,378,080` UTF-8 bytes (`CompanyFoundation_single.html` และ `Company_single.html`) |
| `node tools/benchmark.cjs` | ผ่าน; เฉลี่ย **0.776 ms/tick** (`p95 = 1.193 ms`) ที่ 500 NPC |
| `npm run test:browser` | ไม่ได้รันในคอนเทนเนอร์ออฟไลน์นี้เนื่องจากสภาพแวดล้อมไม่มีแพ็กเกจ npm `playwright` ติดตั้งไว้ล่วงหน้า |

## ประวัติรุ่นและรายงานที่มี

| รุ่น/รายงาน | สาระสำคัญ |
|---|---|
| v0.1.0 foundation | โครงเกมจำลองบริษัทและวงจรการทำงานพื้นฐาน — [รายงาน foundation](docs/company/history/FOUNDATION_REPORT.md) |
| v0.2.0 | บุคลากร อาชีพ ความเป็นอยู่ โบนัส/พี่เลี้ยง และระบบดูแลเครื่องจักร — [รายงาน v0.2.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_2_0.md) |
| v0.3.0 | โครงสร้างอาชีพ/โควตา ประเมินเลื่อนตำแหน่ง และหลายอุตสาหกรรม — [รายงาน v0.3.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_3_0.md) |
| v0.4.0 | ขยายบริษัท อาคาร โลจิสติกส์ B2B และรากฐานโลกภายนอก — [รายงาน v0.4.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_4_0.md) |
| v0.5.0 | อาชีพ 10 ระดับ โครงสร้างและการขยายพื้นที่ — [รายงาน v0.5.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_5_0.md) |
| v0.6.0 | สินทรัพย์ภายนอก ห่วงโซ่ผลิต และ make-or-buy — [รายงาน v0.6.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_6_0.md) |
| v1.0.0 | ห่วงโซ่หลายระดับและระบบนิเวศบริษัทภายนอก — [รายงาน v1.0.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V1_0_0.md) |
| v1.0.0 debug | ตรวจและแก้จุดเชื่อมระบบก่อนเปิดใช้ — [รายงาน debug](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V1_0_0_DEBUG.md) |
| v1.2.0 | ต้นน้ำแท้ วงจรเกษตร และ 8 โมเดลธุรกิจ — [รายงาน v1.2.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V1.2.0.md) |
| v1.3.0 | 10 product families, 9 capability domains, วัตถุดิบ/สินค้าเพิ่ม และ NPC executive board — [รายงาน v1.3.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V1.3.0.md) |
| v2.0.0 | Master Skill สำหรับยุค 2.0 และโลกภูมิรัฐศาสตร์มีชีวิต — [รายงาน v2.0.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V2.0.0.md) |
| v2.1.0 | แก้บั๊ก NPC business-entry ครบ 7 จุด, สายโลหะ/อะลูมิเนียมขั้นบันได, บริการ B2B 8 แบบ, 12 ประเทศ/16 เหตุการณ์โลก และทางเดินการค้า 4 สาย — [รายงาน v2.1.0](docs/company/PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V2.1.0.md) |

## การย้ายสิ่งที่ทำแล้วออกจาก ideas

ใน v2.1.0 ได้ย้ายรายการที่พัฒนาและมีเทสต์ยืนยันแล้วออกจากคลัง `ideas/company/` เพิ่มเติม:
- **บท 34 (`34_business_depth_world_markets_and_npc_entry_audit.md`):** บันทึกการแก้บั๊ก NPC Business-Entry ทั้ง 7 รายการ การเพิ่มสายโลหะขั้นบันได บริการ B2B 2 แบบ (`energy_epc_install`, `b2b_technical_academy`) และประเทศใหม่ 4 ประเทศ (`ID`, `AU`, `IN`, `SG`) พร้อมคงเฉพาะส่วนต่อยอดระยะถัดไป (เช่น ประเทศบราซิล/เกาหลีใต้, โรงถลุงแยกแปลง, ผู้ค้าส่งเต็มรูปแบบ)
- **บท 21 (`21_โมเดลธุรกิจบริการใหม่_10_ประเภท_ทรัพยากร_ขั้นตอน_และผลลัพธ์.md`):** ย้ายศูนย์ฝึกอาชีพสำหรับบริษัทภายนอก (`b2b_technical_academy`) และบริการติดตั้งระบบพลังงาน (`energy_epc_install`) ที่ทำแล้วออก เหลือข้อเสนอ 5 รูปแบบ
- **บท 28 (`28_product_families_and_business_depth.md`):** ตัดสินค้าที่เพิ่มใน v2.1.0 ออก 3 รายการที่ตรงกับตาราง (`P027` ตู้สวิตช์โรงงาน `industrial_switchgear_cabinet`, `P045` เหล็กกล้าแผ่น `structural_steel_plate`, `P046` อะลูมิเนียมโปรไฟล์ `aluminum_extrusion_profile` และชุดรางโซลาร์/ถาดแบต EV/โมดูล NMC) เหลือข้อเสนอ 85 รายการ
- **บท 30 (`30_material_origin_and_supply_chain_registry.md`):** ตัดวัตถุดิบที่เพิ่มใน v2.1.0 ออก (`alumina` / `aluminium_ingot` -> `alumina_billet`, `steel_coil` -> `structural_steel_plate`) เหลือข้อเสนอ 44 รายการ

## เริ่มงานกับ repo นี้

อ่าน [AGENTS.md](AGENTS.md) ก่อนทุกครั้ง จากนั้นอ่าน [START_HERE_FOR_AI.md](START_HERE_FOR_AI.md), [workflow ระหว่างเอเจนต์](docs/company/AGENT_COLLABORATION_WORKFLOW.md), [ทะเบียนงาน](docs/company/AGENT_WORK_STATUS.md), Master Skill และสกิลเฉพาะด้านที่เกี่ยวข้อง ก่อนแก้ source ให้รัน baseline จาก `COMPANY_SOURCE/` และอัปเดตสถานะ/รายงาน/สกิลตามผลตรวจจริง
