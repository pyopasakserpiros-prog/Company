---
name: company-evolution-dev
description: MASTER SKILL for Siam Enterprise / Company Simulation (บริษัทจำลองธุรกิจและอุตสาหกรรมอัตโนมัติ, COMPANY_SOURCE/) up to Era 2.1.0 (v2.1.0). Covers the Permanently Locked Human Core 1.0.0, 10-Level Corporate Hierarchy (Lv.1-Lv.10), 4-Tier Org Tree, 56x34 Greenfield Campus (14 Constructible Facilities), 10 Resource Classes (64 Materials, 40 Recipes, 40 Products in 10 Product Families, Stepped Metals & Extrusion Ladder), 9 Capability Domains, 8 Distinct Business Process Models + 8 Industrial B2B Services, Autonomous NPC Executive Board (Daytime 10:45 AM Review, Reservation vs Paid Capital Separation, Small-Company Entry, Dynamic Service/Client Ranking, Review Cooldowns), Living Global Geopolitics (12 Nations/Governments, 16 Wars/Treaties/Shocks, 4 Trade Corridors, 22 External Corporations, 6 Freight Routes), and 500-NPC High-Performance Scaling (<1ms/tick). MANDATORY RULE: Update this Master Skill on every future patch.
---
# Siam Enterprise: Autonomous Multi-Industry Company Simulation — MASTER ENGINEERING SKILL (Era 2.1.0 / v2.1.0)

> **MANDATORY MASTER SKILL UPDATE RULE**: Whenever a new patch or feature is developed for `Siam Enterprise / Company Simulation (COMPANY_SOURCE/)`, you MUST update both this Master Skill (`company-evolution-dev`) and the Evergreen Workflow Skill (`company-for-every-patch`) in `.agents/skills/`, root `SKILL.md`, and via `skills:update_skill` before completing the turn.

## 1. Core Identity & Architecture Overview (Era 2.1.0)
- **Game Title**: `Siam Enterprise: Autonomous Multi-Industry Company Simulation (บริษัทจำลองธุรกิจและอุตสาหกรรมอัตโนมัติ)`
- **Source Root**: `COMPANY_SOURCE/` (`D.VERSION: "2.1.0"`, `D.RELEASE_VERSION: "2.1.0"`, catalog version `1.2.0`, `S.VERSION: "0.1.0"` as the current simulation/save state marker, package.json version `0.1.0`)
- **Standalone Build**: `COMPANY_SOURCE/CompanyFoundation_single.html` and `Company_single.html` (built via `node tools/build.cjs`, `1,378,080` UTF-8 bytes, 100% Offline)
- **Permanently Locked Human Core 1.0.0 (`COMPANY_SOURCE/js/human-core.js`)**:
  - **HARD INVARIANT**: Never modify `js/human-core.js` or `CORE_LOCK.json` (`SHA-256: fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`).
  - Drives 14 Personality traits, 18 Values, 30 Aptitudes, and 12 Vitality States for every employee, manager, and CEO.

## 2. Complete System Architecture (Up to Era 2.1.0)
1. **10-Level Corporate Hierarchy (`Lv.1–Lv.10 / G1–G10`) & 4-Tier Organizational Tree**:
   - Divisions: Executive (`executive`), White-Collar Office (`office`: Sales, Admin/Procurement/Finance, R&D), and Blue-Collar Factory (`factory`: Production, QC/QA, Warehouse/Logistics).
   - 4-Tier Structure: Division ➔ Department ➔ Section ➔ Group (`D.ORG_TREE` & `D.resolveOrgAssignment`).
   - Span-of-Control Headcount Quotas (`CAREER_QUOTAS` & `getDepartmentHeadroom`) and Boss Promotion Evaluation (`evaluatePromotions`: Merit vs Favoritism/Nepotism with `promotionGrievance` ripple effects).
2. **56×34 Greenfield Industrial Estate & 14 Constructible Expansion Facilities (`D.EXPANSION_PLOTS`)**:
   - 8 Core Campus Buildings (`hq`, `rnd`, `factory`, `warehouse`, `canteen`, `courtyard`, `training`, `gate`) + 14 Constructible Plots (`rawDepot`, `prodLineB`, `prodLineC`, `cleanroomPlant`, `dispatchHub`, `execAnnex`, `maintWorkshop`, `qaLab`, `solarPlant`, `waterPlant`, `refineryMill`, `bakeryPlant`, `expoHall`, `dormitory`).
3. **10 Resource Classes, 64 Materials, 40 Multi-Stage Recipes & True Elemental Provenance (`D.RESOURCE_CLASSES`, `D.MATERIAL_RECIPES`)**:
   - **True Natural Resources (`T0_NATURAL` — 9 items)**: `silica_bauxite_ore`, `bauxite_ore`, `copper_iron_ore`, `lithium_brine_ore`, `phosphate_potash_rock`, `crude_petro_feedstock`, `raw_water_m3`, `ambient_air_gas`, `iron_ore` (`silica_copper_mine` yields `silica_bauxite_ore: 3, copper_iron_ore: 2, iron_ore: 2, bauxite_ore: 3` against finite mine reserves).
   - **Biological Seeds & Cuttings (`SEED_STOCK` — 5 items)**: `rice_seed`, `wheat_seed`, `cane_stalk_seed`, `palm_seedling`, `soybean_seed` (`milled_rice`, `artisan_flour`, and `wheat_flour` have `cannotPlantAsSeed: true`).
   - **Cultivated Crops, Livestock & Forestry Logs (`CULTIVATED_CROP` — 8 items)**: `paddy_grain`, `wheat_grain`, `raw_cane`, `crude_palm`, `soybean_crop`, `fresh_milk_soy`, `natural_latex`, `timber_bamboo_log`.
   - **Stepped Metals & Extrusion Ladder (v2.1.0)**:
     - Added 6 materials: `coke_reducing_flux`, `alumina_billet`, `structural_steel_plate`, `mineral_slag_mud` (`INDUSTRIAL_BYPRODUCT`), `nickel_cobalt_matte`, `aluminum_extrusion_profile` (**64 materials total**: `9` T0, `37` T1, `10` T2, `8` T3).
     - Added 5 recipes (`recipe_coke_reducing_flux`, `recipe_alumina_billet`, `recipe_structural_steel_plate`, `recipe_aluminum_extrusion_profile`, `recipe_nickel_cobalt_matte` -> **40 recipes total**) + `alternativeInputs` on `metal_sheet`, `heat_sink`, and `cathode_electrolyte`.
     - Smelting `alumina_billet`, `structural_steel_plate`, or `nickel_cobalt_matte` generates `mineral_slag_mud` byproduct, which can be treated into `composite_pellet` via `S.treatMineralSlag(w, batchCount)`.
4. **9 Capability Domains (`D.CAPABILITY_DOMAINS`), 10 Product Families (`D.PRODUCT_FAMILIES`), and 40 Products**:
   - 9 Domains: `food_fermentation`, `metal_machining`, `power_electronics`, `embedded_iot`, `semiconductor_optics`, `biomed_sterile`, `software_cloud`, `fleet_coldchain`, `agri_soil_science`.
   - 4 Stepped Metals/Energy Products added in v2.1.0 (**40 products total**): `solar_mounting_rail_kit`, `ev_battery_tray_assembly`, `industrial_switchgear_cabinet`, `high_nickel_nmc_module`.
5. **8 Distinct Business Process Models & 8 Industrial B2B Services (`D.BUSINESS_PROCESS_MODELS`, `D.SECTOR_PROCESS_MODELS`, `D.INDUSTRIAL_SERVICES`)**:
   - **4 Factory Sector Engines (`w.sectorProcesses`)**: `food_bakery_batch`, `electronics_smt_rma`, `automotive_oem_tooling`, `biomed_sterile_lot`.
   - **True Upstream Agriculture, Livestock, Mining & Forestry (`w.agriculture`)**: 8-stage crop cycle, dairy herd feeding, finite mine reserve depletion & geological survey, and 3-age forestry rotation.
   - **Fleet Freight Transport (`w.fleetTransport`)**: 3 vehicle types (`dry_6w`, `reefer_6w`, `heavy_10w`) with explicit `leaseDepositSatang` (`dailyLeaseCost * 5`: `900000`, `1250000`, `1700000`) and **6 freight routes** (`FREIGHT_ROUTES`, including `route_eec_singapore_feeder` and `route_maptaphut_metal_heavy`).
   - **Software House & SaaS (`w.softwareBusiness`)**: 8 apps, 30/40/30 milestone accounting (`unearnedDepositSatang`), strict engineer qualification & QA defect gate, and SaaS active subscriber billing.
   - **8 Industrial B2B Services (`w.serviceBusiness`)**: `calibration_lab`, `field_maintenance`, `industrial_recycling`, `battery_second_life_lab`, `returnable_pallet_pool`, `cold_storage_3pl`, `energy_epc_install` (Solar/Energy EPC installation consuming `solar_mounting_rail_kit` + `copper_coil`), and `b2b_technical_academy` (B2B engineering training consuming instructor capacity + `pcb` + `sensor_pack`).
6. **Autonomous NPC Executive Board & Decision Ledger (`w.executiveBoard`, `evaluateExecutiveBoardAndBusinessEntry` — Audited & Fixed in v2.1.0)**:
   - **Daytime Executive Review (`tod(w) === 645` / 10:45 AM)**: Runs during active office hours in `step(w)` when the CEO/senior leader is physically `atWork`, eliminating the midnight `deferred_no_executive_authority` bug without relying on `ignoreAtWork`.
   - **Reservation vs. Paid Capital Separation**: `reserveBoardBudget`, `consumeBoardReservation`, and `cancelBoardReservation` keep unpaid reservations (`committedBudgetSatang` / `eb.reservations`) strictly separate from already-paid capital (`paidCapitalTotalSatang`), preventing double deduction from `uncommittedCashSatang`.
   - **Small-Company Entry (<10 Staff), Uncommitted Service Gate, Dynamic Ranking & Cooldowns**: Companies with `<10` staff can autonomously lease a starter truck or open a single-specialist B2B service; `service_entry` checks `remainingUncommitted`; services and client corporations are ranked by demand, margin, spare-part readiness, and trust; `nextReviewDay` & `eb.topicCooldowns` prevent daily duplicate ledger spam.
7. **Era 2.1.0 Living Global Geopolitics, 4 Trade Corridors & World Chronicle (`w.externalWorld.geopolitics`, `D.TRADE_CORRIDORS`)**:
   - **12 Sovereign Nations & Blocs (`D.GLOBAL_NATIONS`)**: `TH`, `US`, `CN`, `JP`, `EU`, `ME`, `RU_EE`, `ASEAN`, plus `ID` (Indonesia), `AU` (Australia), `IN` (India), `SG` (Singapore).
   - **16 Global Geopolitical Events (`D.GEOPOLITICAL_EVENTS`)**: Includes `indonesia_nickel_bauxite_ban`, `australia_pilbara_cyclone_iron_shock`, `singapore_asean_coldchain_corridor`, and `india_apac_clean_grid_pharma_boom`.
   - **22 Multi-Role External Corporations (`D.EXTERNAL_CORPORATIONS`) & 4 Regional Trade Corridors (`D.TRADE_CORRIDORS`)**: Added `nusantara_nickel`, `pilbara_resources`, `bharat_biotech_it`, `singapore_port_3pl` and 4 observable regional trade corridors exposed via `snap.externalWorld.tradeCorridors`.

## 3. Verification & Benchmark Suite
```bash
cd COMPANY_SOURCE
node tools/verify.cjs
node tools/test.cjs
node tools/build.cjs
node tools/benchmark.cjs
```
- All **136/136** unit tests pass with 0 failures (`~0.776 ms/tick` at 500 concurrent NPCs).
