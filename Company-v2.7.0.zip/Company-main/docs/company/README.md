# ดัชนีเอกสาร Company

เปิดจากหน้านี้เพื่อหาเอกสารตามงาน ไม่ต้องไล่หาไฟล์จากรายชื่อปะปน

## ระบบล่าสุดv2.6.0

- [โรงงาน เครื่องมือและสัญญา](PLANT_AND_COMMERCIAL_SYSTEM.md)
- [รายงานv2.6.0](PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V2.6.0.md)
- [รับช่วง](PLANT_V260_HANDOFF.md)

## สถานะงานและคำสั่ง

- [ACTIVE_PROMPT.md](../../ACTIVE_PROMPT.md) — สถานะคำสั่งล่าสุดและพรอมต์ประวัติ อยู่ที่ราก repo
- [ทะเบียนงาน](AGENT_WORK_STATUS.md) — ใครทำอะไรและสถานะล่าสุด
- [สถานะเกม](../../project_status_and_ai_onboarding.md) — ระบบที่ยืนยันใน source และงานที่ยังค้าง
- [วิสัยทัศน์ผู้เล่น](PLAYER_VISION_AND_DESIGN_PRINCIPLES.md) — เป้าหมายเกมและหลักการออกแบบ

## โลกภายนอกล่าสุด

- [คู่มือโลก v2.4.0](LIVING_WORLD_SYSTEM.md)
- [รายงานแพตช์ v2.4.0](PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_COMPANY_V2.4.0.md)
- [รับช่วงและข้อเสนอขั้นต่อไป](WORLD_V240_HANDOFF.md)

## ระบบความรู้และเทมเพลต

- [คู่มือวิชาและความพร้อมธุรกิจ](LEARNED_KNOWLEDGE_SYSTEM.md)
- [ทะเบียนวิชาและตารางธุรกิจ](KNOWLEDGE_SUBJECT_CATALOG.md)
- [เทมเพลตสร้างวิชา](templates/KNOWLEDGE_SUBJECT_TEMPLATE.md)
- [แหล่งค้นคว้าจากหลักสูตร/กรอบอาชีพจริง](research/KNOWLEDGE_CURRICULUM_SOURCES.md)

## หมวดเอกสาร

| หมวด | ใช้หาอะไร |
|---|---|
| [PATCH_REPORTS](PATCH_REPORTS/README.md) | รายงานแพตช์และรายงานอัปเดตเอกสาร เรียงตามรุ่น/วันที่ |
| [design](design/README.md) | สเปกระบบและแบบออกแบบที่ใช้อ้างอิง |
| [research](research/README.md) | งานวิจัยและข้อเสนอที่ยังต้องเทียบกับ source |
| [prompts/archive](prompts/archive/README.md) | พรอมต์เก่าที่เก็บเป็นประวัติ; ไม่ใช่คำสั่งปัจจุบัน |
| [validation](validation/README.md) | baseline, checksum และ coverage matrix |
| [history](history/README.md) | แบบแปลน/เอกสารจากช่วงก่อนหน้า ไม่ใช่ source of truth ปัจจุบัน |
| [SKILL_STARTER_HANDOFF](SKILL_STARTER_HANDOFF/README.md) | ชุดร่างสกิลและเอกสารส่งต่อให้ Gemini |

เอกสารทำงานปัจจุบันให้ยึด AGENTS.md, START_HERE_FOR_AI.md, project status และ source ใน COMPANY_SOURCE ตามลำดับที่เกี่ยวข้อง ประวัติและข้อเสนอไม่ยืนยันว่าระบบมีอยู่จริง
